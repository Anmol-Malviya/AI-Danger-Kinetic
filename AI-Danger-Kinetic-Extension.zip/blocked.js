// ── Particle background ──────────────────────────────────────
(function initParticles() {
  const canvas = document.getElementById("particles-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  let W = canvas.width = window.innerWidth;
  let H = canvas.height = window.innerHeight;
  window.addEventListener("resize", () => {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  });

  const particles = Array.from({ length: 55 }, () => ({
    x: Math.random() * W,
    y: Math.random() * H,
    r: Math.random() * 1.4 + 0.4,
    vx: (Math.random() - 0.5) * 0.3,
    vy: (Math.random() - 0.5) * 0.3,
    alpha: Math.random() * 0.4 + 0.1,
    color: Math.random() > 0.6 ? "239,68,68" : "6,182,212"
  }));

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${p.color},${p.alpha})`;
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  draw();
})();

// ── Main Page Logic ──────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  const params        = new URLSearchParams(window.location.search);
  const blockedUrl    = params.get("url")        || "";
  const threat        = params.get("threat")      || "dangerous";
  const confidence    = parseFloat(params.get("confidence") || "0");
  const detailsStr    = params.get("details")    || "[]";

  // DOM refs
  const blockedUrlEl  = document.getElementById("blocked-url");
  const threatLevelEl = document.getElementById("threat-level");
  const meterFill     = document.getElementById("meter-fill");
  const meterGlow     = document.getElementById("meter-glow");
  const meterValue    = document.getElementById("meter-value");
  const terminalBox   = document.getElementById("terminal-box");
  const terminalBody  = document.getElementById("terminal-body");
  const btnBack       = document.getElementById("btn-back");
  const btnBypass     = document.getElementById("btn-bypass");

  // Populate URL
  blockedUrlEl.textContent = blockedUrl || "Unknown";
  blockedUrlEl.title = blockedUrl;

  // Threat badge
  threatLevelEl.textContent = threat.toUpperCase();

  // Animate threat meter
  setTimeout(() => {
    meterFill.style.width = `${confidence}%`;
    meterGlow.style.width = `${confidence}%`;
  }, 300);

  // Count-up animation for meter value
  let start = 0;
  const end = Math.round(confidence);
  const duration = 1800;
  const step = end / (duration / 16);
  const counter = setInterval(() => {
    start = Math.min(start + step, end);
    meterValue.textContent = `${Math.round(start)}%`;
    if (start >= end) clearInterval(counter);
  }, 16);

  // Parse heuristics
  let details = [];
  try { details = JSON.parse(detailsStr); } catch (_) {}

  if (details.length > 0) {
    terminalBox.style.display = "block";

    // System init lines
    const initLines = [
      { msg: "Initializing heuristics scanner...", safe: true },
      { msg: `Target URL: ${blockedUrl.substring(0, 55)}${blockedUrl.length > 55 ? "…" : ""}`, safe: true },
      { msg: `Threat classification: ${threat.toUpperCase()} (confidence: ${Math.round(confidence)}%)`, safe: false },
    ];

    const allLines = [
      ...initLines,
      ...details.map(d => ({ msg: d, safe: false }))
    ];

    allLines.forEach((item, i) => {
      setTimeout(() => {
        const line = document.createElement("div");
        line.className = "terminal-line";
        line.style.animationDelay = "0s";
        const prefix = document.createElement("span");
        prefix.className = "prefix";
        prefix.textContent = item.safe ? "[$]" : "[!]";
        const msg = document.createElement("span");
        msg.className = `msg${item.safe ? " safe" : ""}`;
        msg.textContent = item.msg;
        line.appendChild(prefix);
        line.appendChild(msg);
        terminalBody.appendChild(line);
      }, 200 + i * 280);
    });
  }

  // Go back
  btnBack.addEventListener("click", () => {
    if (history.length > 1) {
      history.back();
      setTimeout(() => { window.location.href = "https://www.google.com"; }, 300);
    } else {
      window.location.href = "https://www.google.com";
    }
  });

  // Bypass
  btnBypass.addEventListener("click", async () => {
    if (!blockedUrl) return;
    try {
      const hostname = new URL(blockedUrl).hostname;
      const stored = await chrome.storage.local.get({ whitelist: [] });
      const whitelist = stored.whitelist;
      if (!whitelist.includes(hostname)) {
        whitelist.push(hostname);
        await chrome.storage.local.set({ whitelist });
      }
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        chrome.runtime.sendMessage({ action: "recheckTab", tabId: tab.id, url: blockedUrl });
      } else {
        window.location.href = blockedUrl;
      }
    } catch (e) {
      window.location.href = blockedUrl;
    }
  });
});
